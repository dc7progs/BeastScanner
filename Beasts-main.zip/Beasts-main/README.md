https://www.ownedcore.com/forums/mmo/path-of-exile/poe-bots-programs/1001716-exileapi-poehelper-poehud-plugin-beasts-easily-find-profitable-beasts.html
